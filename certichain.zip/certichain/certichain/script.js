/**
 * script.js — CertiChain v3
 * Kelompok 1, Blockchain Kelas C, Institut Teknologi PLN
 *
 * Multi-page SPA + Integrasi Ethers.js v6 + MetaMask
 * Smart contract: CertificateSystem.sol (Sepolia Testnet)
 */

// ════════════════════════════════════════════
//  KONFIGURASI — ganti CONTRACT_ADDRESS setelah deploy
// ════════════════════════════════════════════
const CONTRACT_ADDRESS = "0x240BAe76A9b69339a626A6D2120B70d677bdAF85";

const CONTRACT_ABI = [
  "function owner() view returns (address)",
  "function certificateCount() view returns (uint256)",
  "function authorizedIssuers(address) view returns (bool)",
  "function createCertificate(string _recipientName, string _courseName) returns (uint256)",
  "function getCertificate(uint256 _id) view returns (uint256 id, string recipientName, string courseName, uint256 issueDate, bool isValid, address issuedBy)",
  "function verifyCertificate(uint256 _id) view returns (bool isAuthentic, string message)",
  "function revokeCertificate(uint256 _id)",
  "event CertificateCreated(uint256 indexed id, string recipientName, string courseName, address issuedBy)",
  "event CertificateRevoked(uint256 indexed id, address revokedBy)"
];

// ════════════════════════════════════════════
//  STATE GLOBAL
// ════════════════════════════════════════════
let provider    = null;
let signer      = null;
let contract    = null;
let userAddress = null;

// ════════════════════════════════════════════
//  NAVIGASI HALAMAN (SPA)
// ════════════════════════════════════════════

/**
 * Pindah antar halaman tanpa reload
 * @param {string} page — 'home' | 'app' | 'explorer' | 'about'
 */
function navigateTo(page) {
  // Sembunyikan semua halaman
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));

  // Tampilkan halaman yang dipilih
  const target = document.getElementById(`page-${page}`);
  if (target) target.classList.add('active');

  // Update nav link aktif
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.toggle('active', link.dataset.page === page);
  });

  // Scroll ke atas
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Load stats jika ke home atau explorer
  if (page === 'home' || page === 'explorer') loadStats();
}

// ════════════════════════════════════════════
//  UTILITAS
// ════════════════════════════════════════════

/** Tampilkan notifikasi banner */
function showAlert(msg, type = 'info') {
  const banner = document.getElementById('alertBanner');
  const icon   = document.getElementById('alertIcon');
  const msgEl  = document.getElementById('alertMsg');

  const icons = { success: '✓', error: '✕', info: 'i' };
  icon.textContent  = icons[type] || 'i';
  msgEl.textContent = msg;

  banner.className = `alert-banner alert-${type}`;
  banner.classList.remove('hidden');

  clearTimeout(banner._timer);
  banner._timer = setTimeout(closeAlert, 6000);
}

function closeAlert() {
  document.getElementById('alertBanner').classList.add('hidden');
}

/** Tampilkan/sembunyikan loading overlay transaksi */
function showTxProgress(show, msg = 'Memproses transaksi...') {
  const el    = document.getElementById('txProgress');
  const msgEl = document.getElementById('txMsg');
  msgEl.textContent = msg;
  el.classList.toggle('hidden', !show);
}

/** Format UNIX timestamp → tanggal Indonesia */
function formatDate(timestamp) {
  const date = new Date(Number(timestamp) * 1000);
  return date.toLocaleDateString('id-ID', {
    day: 'numeric', month: 'long', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

/** Format UNIX timestamp → tanggal pendek */
function formatDateShort(timestamp) {
  const date = new Date(Number(timestamp) * 1000);
  return date.toLocaleDateString('id-ID', {
    day: '2-digit', month: 'short', year: 'numeric'
  });
}

/** Persingkat alamat Ethereum: 0x1234...abcd */
function shortenAddress(addr) {
  if (!addr || addr.length < 10) return addr;
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

// ════════════════════════════════════════════
//  KONEKSI METAMASK
// ════════════════════════════════════════════

async function connectWallet() {
  if (!window.ethereum) {
    showAlert('MetaMask tidak terdeteksi! Install dulu di browser kamu.', 'error');
    return;
  }

  try {
    showAlert('Membuka MetaMask...', 'info');

    // Minta akses ke akun
    await window.ethereum.request({ method: 'eth_requestAccounts' });

    provider    = new ethers.BrowserProvider(window.ethereum);
    signer      = await provider.getSigner();
    userAddress = await signer.getAddress();

    // Validasi jaringan — harus Sepolia (chainId: 11155111)
    const network = await provider.getNetwork();
    if (network.chainId !== 11155111n) {
      showAlert('Kamu tidak di Sepolia Testnet! Ganti jaringan di MetaMask ke Sepolia.', 'error');
      signer = null;
      return;
    }

    // Buat instance smart contract
    contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

    // Update UI
    updateWalletUI(true);
    showAlert(`Wallet terhubung: ${shortenAddress(userAddress)}`, 'success');

    // Muat data statistik
    await loadStats();

    // Event listeners untuk perubahan akun/jaringan di MetaMask
    window.ethereum.on('accountsChanged', handleAccountChange);
    window.ethereum.on('chainChanged', () => window.location.reload());

  } catch (err) {
    console.error('Gagal connect:', err);
    if (err.code === 4001) {
      showAlert('Koneksi ditolak. Setujui permintaan di MetaMask.', 'error');
    } else {
      showAlert('Gagal terhubung: ' + err.message, 'error');
    }
  }
}

/** Update tampilan header setelah connect/disconnect */
function updateWalletUI(connected) {
  const connectBtn    = document.getElementById('connectBtn');
  const walletInfo    = document.getElementById('walletInfo');
  const networkBadge  = document.getElementById('networkBadge');
  const walletAddress = document.getElementById('walletAddress');

  if (connected) {
    connectBtn.classList.add('hidden');
    walletInfo.classList.remove('hidden');
    networkBadge.classList.remove('hidden');
    walletAddress.textContent = shortenAddress(userAddress);
  } else {
    connectBtn.classList.remove('hidden');
    walletInfo.classList.add('hidden');
    networkBadge.classList.add('hidden');
  }
}

async function handleAccountChange(accounts) {
  if (accounts.length === 0) {
    signer = contract = userAddress = null;
    updateWalletUI(false);
    showAlert('Wallet terputus.', 'info');
  } else {
    window.location.reload();
  }
}

// ════════════════════════════════════════════
//  LOAD STATISTIK
// ════════════════════════════════════════════

async function loadStats() {
  if (!contract) return;
  try {
    const [count, ownerAddr] = await Promise.all([
      contract.certificateCount(),
      contract.owner()
    ]);

    // Update semua elemen statistik di semua halaman
    document.querySelectorAll('#statTotal, #statTotalApp').forEach(el => {
      if (el) el.textContent = count.toString();
    });
    document.querySelectorAll('#statOwner, #statOwnerHome').forEach(el => {
      if (el) el.textContent = shortenAddress(ownerAddr);
    });
  } catch (err) {
    console.warn('Gagal memuat statistik:', err);
  }
}

// ════════════════════════════════════════════
//  FUNGSI 1: createCertificate — WRITE
//  Menerbitkan sertifikat baru ke blockchain
// ════════════════════════════════════════════

async function createCertificate() {
  if (!contract) {
    showAlert('Hubungkan wallet MetaMask terlebih dahulu!', 'error');
    return;
  }

  const recipientName = document.getElementById('recipientName').value.trim();
  const courseName    = document.getElementById('courseName').value.trim();

  if (!recipientName) { showAlert('Nama peserta tidak boleh kosong!', 'error'); return; }
  if (!courseName)    { showAlert('Nama kursus tidak boleh kosong!', 'error'); return; }

  const resultBox = document.getElementById('createResult');
  const btn       = document.getElementById('createBtn');

  try {
    btn.disabled = true;
    showTxProgress(true, 'Mengirim transaksi ke MetaMask...');

    // Kirim transaksi — MetaMask popup akan muncul
    const tx = await contract.createCertificate(recipientName, courseName);
    showTxProgress(true, 'Transaksi terkirim — menunggu konfirmasi blockchain...');

    // Tunggu 1 block confirmation
    const receipt = await tx.wait(1);

    // Parse event untuk mendapatkan ID sertifikat baru
    let newId = '?';
    try {
      const iface = new ethers.Interface(CONTRACT_ABI);
      for (const log of receipt.logs) {
        try {
          const parsed = iface.parseLog(log);
          if (parsed?.name === 'CertificateCreated') {
            newId = parsed.args.id.toString();
            break;
          }
        } catch (_) { /* bukan log dari kontrak ini, skip */ }
      }
    } catch (_) { /* fallback */ }

    resultBox.innerHTML = `
      ✓ Sertifikat berhasil diterbitkan!<br/>
      ID: <strong>#${newId}</strong> &nbsp;|&nbsp; Block: #${receipt.blockNumber}<br/>
      Tx: ${shortenAddress(receipt.hash)}
    `;
    resultBox.className = 'result-box success';
    resultBox.classList.remove('hidden');

    showAlert(`Sertifikat #${newId} berhasil diterbitkan ke blockchain!`, 'success');

    // Reset form
    document.getElementById('recipientName').value = '';
    document.getElementById('courseName').value    = '';

    await loadStats();

  } catch (err) {
    console.error('Error createCertificate:', err);
    let msg = 'Transaksi gagal.';
    if (err.code === 4001)                               msg = 'Transaksi dibatalkan pengguna.';
    else if (err.message?.includes('insufficient funds')) msg = 'Saldo ETH tidak cukup untuk gas!';
    else if (err.reason)                                  msg = 'Kontrak: ' + err.reason;

    resultBox.textContent = '✕ ' + msg;
    resultBox.className   = 'result-box error';
    resultBox.classList.remove('hidden');
    showAlert(msg, 'error');

  } finally {
    btn.disabled = false;
    showTxProgress(false);
  }
}

// ════════════════════════════════════════════
//  FUNGSI 2: getCertificate — READ (gratis)
//  Mengambil data sertifikat berdasarkan ID
// ════════════════════════════════════════════

async function getCertificate() {
  if (!contract) {
    showAlert('Hubungkan wallet MetaMask terlebih dahulu!', 'error');
    return;
  }

  const id = document.getElementById('getCertId').value;
  if (!id || id < 1) { showAlert('Masukkan ID sertifikat yang valid!', 'error'); return; }

  const certCard = document.getElementById('certCard');

  try {
    showTxProgress(true, 'Mengambil data dari blockchain...');

    // Fungsi view — tidak butuh gas, baca langsung dari node
    const result = await contract.getCertificate(Number(id));
    const [certId, recipientName, courseName, issueDate, isValid, issuedBy] = result;

    // Isi DOM dengan data dari blockchain
    document.getElementById('cardId').textContent     = '#' + certId.toString();
    document.getElementById('cardName').textContent   = recipientName;
    document.getElementById('cardCourse').textContent = courseName;
    document.getElementById('cardDate').textContent   = formatDate(issueDate);
    document.getElementById('cardIssuer').textContent = issuedBy;

    // Badge status
    const badge = document.getElementById('certStatusBadge');
    if (isValid) {
      badge.textContent = '● AKTIF';
      badge.className   = 'cert-status valid';
    } else {
      badge.textContent = '✕ DICABUT';
      badge.className   = 'cert-status revoked';
    }

    certCard.classList.remove('hidden');
    showAlert('Data sertifikat berhasil dimuat dari blockchain!', 'success');

  } catch (err) {
    console.error('Error getCertificate:', err);
    certCard.classList.add('hidden');
    const msg = err.reason || 'Sertifikat tidak ditemukan.';
    showAlert('✕ ' + msg, 'error');

  } finally {
    showTxProgress(false);
  }
}

// ════════════════════════════════════════════
//  FUNGSI 3: verifyCertificate — READ (gratis)
//  Memverifikasi keaslian dan status sertifikat
// ════════════════════════════════════════════

async function verifyCertificate() {
  if (!contract) {
    showAlert('Hubungkan wallet MetaMask terlebih dahulu!', 'error');
    return;
  }

  const id = document.getElementById('verifyCertId').value;
  if (!id || id < 1) { showAlert('Masukkan ID sertifikat yang valid!', 'error'); return; }

  const display = document.getElementById('verifyResult');

  try {
    showTxProgress(true, 'Memverifikasi sertifikat...');

    const [isAuthentic, message] = await contract.verifyCertificate(Number(id));

    // Update UI verifikasi
    document.getElementById('verifyIcon').textContent   = isAuthentic ? '✓' : '✕';
    document.getElementById('verifyMsg').textContent    = message;
    document.getElementById('verifyStatus').textContent = isAuthentic
      ? `Sertifikat #${id} valid dan masih aktif di blockchain`
      : `Sertifikat #${id} tidak valid atau telah dicabut`;

    display.className = `verify-display ${isAuthentic ? 'valid' : 'invalid'}`;
    display.classList.remove('hidden');

    showAlert(
      isAuthentic ? `Sertifikat #${id} VALID ✓` : `Sertifikat #${id} tidak valid`,
      isAuthentic ? 'success' : 'error'
    );

  } catch (err) {
    console.error('Error verifyCertificate:', err);
    document.getElementById('verifyIcon').textContent   = '?';
    document.getElementById('verifyMsg').textContent    = 'Gagal memverifikasi.';
    document.getElementById('verifyStatus').textContent = 'ID mungkin tidak ditemukan di blockchain.';
    display.className = 'verify-display invalid';
    display.classList.remove('hidden');
    showAlert('Gagal memverifikasi sertifikat.', 'error');

  } finally {
    showTxProgress(false);
  }
}

// ════════════════════════════════════════════
//  FUNGSI 4: revokeCertificate — WRITE
//  Mencabut sertifikat (hanya issuer/owner)
// ════════════════════════════════════════════

async function revokeCertificate() {
  if (!contract) {
    showAlert('Hubungkan wallet MetaMask terlebih dahulu!', 'error');
    return;
  }

  const id = document.getElementById('revokeCertId').value;
  if (!id || id < 1) { showAlert('Masukkan ID sertifikat yang valid!', 'error'); return; }

  // Konfirmasi sebelum eksekusi (tindakan permanen)
  const confirmed = window.confirm(
    `⚠️ Yakin ingin mencabut sertifikat #${id}?\n\nTindakan ini PERMANEN dan tidak dapat dibatalkan.`
  );
  if (!confirmed) return;

  const resultBox = document.getElementById('revokeResult');
  const btn       = document.getElementById('revokeBtn');

  try {
    btn.disabled = true;
    showTxProgress(true, 'Mengirim transaksi pencabutan ke MetaMask...');

    const tx = await contract.revokeCertificate(Number(id));
    showTxProgress(true, 'Menunggu konfirmasi blockchain...');

    const receipt = await tx.wait(1);

    resultBox.innerHTML = `
      ✓ Sertifikat #${id} berhasil dicabut!<br/>
      Block: #${receipt.blockNumber} &nbsp;|&nbsp; Tx: ${shortenAddress(receipt.hash)}
    `;
    resultBox.className = 'result-box success';
    resultBox.classList.remove('hidden');

    document.getElementById('revokeCertId').value = '';
    showAlert(`Sertifikat #${id} berhasil dicabut dari blockchain.`, 'success');

  } catch (err) {
    console.error('Error revokeCertificate:', err);
    let msg = 'Gagal mencabut sertifikat.';
    if (err.code === 4001)                                msg = 'Transaksi dibatalkan pengguna.';
    else if (err.message?.includes('tidak memiliki izin')) msg = 'Kamu tidak berhak mencabut sertifikat ini.';
    else if (err.message?.includes('sudah tidak aktif'))   msg = 'Sertifikat sudah dicabut sebelumnya.';
    else if (err.reason)                                   msg = err.reason;

    resultBox.textContent = '✕ ' + msg;
    resultBox.className   = 'result-box error';
    resultBox.classList.remove('hidden');
    showAlert(msg, 'error');

  } finally {
    btn.disabled = false;
    showTxProgress(false);
  }
}

// ════════════════════════════════════════════
//  EXPLORER — Halaman browser sertifikat
// ════════════════════════════════════════════

/** Cari sertifikat by ID di explorer */
async function explorerSearch() {
  if (!contract) {
    showAlert('Hubungkan wallet MetaMask terlebih dahulu!', 'error');
    return;
  }

  const id = document.getElementById('explorerSearchId').value;
  if (!id || id < 1) { showAlert('Masukkan ID yang valid!', 'error'); return; }

  const resultEl = document.getElementById('explorerResult');

  try {
    showTxProgress(true, 'Mencari sertifikat...');

    const result = await contract.getCertificate(Number(id));
    const [certId, recipientName, courseName, issueDate, isValid, issuedBy] = result;

    resultEl.innerHTML = buildExplorerCard(certId, recipientName, courseName, issueDate, isValid, issuedBy, true);
    resultEl.classList.remove('hidden');

  } catch (err) {
    resultEl.innerHTML = `
      <div style="padding:16px;background:var(--red-bg);border:1px solid var(--red-bd);border-radius:var(--r);color:var(--red-d);font-size:0.88rem;">
        ✕ Sertifikat tidak ditemukan dengan ID tersebut.
      </div>
    `;
    resultEl.classList.remove('hidden');
  } finally {
    showTxProgress(false);
  }
}

/** Muat semua sertifikat dari blockchain */
async function explorerLoadAll() {
  if (!contract) {
    showAlert('Hubungkan wallet MetaMask terlebih dahulu!', 'error');
    return;
  }

  const listEl = document.getElementById('explorerList');

  try {
    showTxProgress(true, 'Mengambil semua sertifikat dari blockchain...');

    const total = await contract.certificateCount();
    const count = Number(total);

    if (count === 0) {
      listEl.innerHTML = `
        <div class="explorer-empty">
          <span class="explorer-empty-icon">⊙</span>
          <p>Belum ada sertifikat yang diterbitkan di blockchain.</p>
        </div>
      `;
      showTxProgress(false);
      return;
    }

    // Ambil semua sertifikat secara paralel
    showTxProgress(true, `Memuat ${count} sertifikat dari blockchain...`);
    const promises = [];
    for (let i = 1; i <= count; i++) {
      promises.push(contract.getCertificate(i));
    }
    const certs = await Promise.all(promises);

    // Render kartu-kartu
    listEl.innerHTML = certs.map(cert => {
      const [certId, recipientName, courseName, issueDate, isValid, issuedBy] = cert;
      return buildExplorerCard(certId, recipientName, courseName, issueDate, isValid, issuedBy, false);
    }).join('');

    showAlert(`Berhasil memuat ${count} sertifikat dari blockchain!`, 'success');

  } catch (err) {
    console.error('Explorer error:', err);
    showAlert('Gagal memuat data dari blockchain.', 'error');
  } finally {
    showTxProgress(false);
  }
}

/** Build HTML untuk satu kartu explorer */
function buildExplorerCard(certId, recipientName, courseName, issueDate, isValid, issuedBy, isSearchResult) {
  const statusClass = isValid ? 'valid' : 'revoked';
  const statusText  = isValid ? 'AKTIF' : 'DICABUT';
  const dateStr     = formatDateShort(issueDate);
  const issuerShort = shortenAddress(issuedBy);

  const wrapStart = isSearchResult
    ? `<div style="background:var(--bg-2);border:1.5px solid var(--orange-bd);border-radius:var(--r-lg);padding:20px;box-shadow:var(--shadow);">`
    : `<div class="explorer-cert-card">`;

  return `
    ${wrapStart}
      <div class="explorer-cert-top">
        <span class="explorer-cert-id">ID #${certId.toString()}</span>
        <span class="explorer-cert-status ${statusClass}">${statusText}</span>
      </div>
      <div class="explorer-cert-name">${recipientName}</div>
      <div class="explorer-cert-course">${courseName}</div>
      <div class="explorer-cert-footer">
        <span class="explorer-cert-date">${dateStr}</span>
        <span style="font-family:var(--font-mono);font-size:0.72rem;color:var(--text-3);">${issuerShort}</span>
      </div>
    </div>
  `;
}

// ════════════════════════════════════════════
//  INISIALISASI — Saat DOM siap
// ════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {

  // ── Header scroll shadow ──
  const header = document.getElementById('header');
  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 10);
  });

  // ── Input focus: highlight label ──
  document.querySelectorAll('.input-field').forEach(input => {
    input.addEventListener('focus', () => {
      const label = input.closest('.input-group')?.querySelector('.input-label');
      if (label) label.style.color = 'var(--orange)';
    });
    input.addEventListener('blur', () => {
      const label = input.closest('.input-group')?.querySelector('.input-label');
      if (label) label.style.color = '';
    });
  });

  // ── Enter key untuk explorer search ──
  const explorerInput = document.getElementById('explorerSearchId');
  if (explorerInput) {
    explorerInput.addEventListener('keydown', e => {
      if (e.key === 'Enter') explorerSearch();
    });
  }

  // ── Explorer "Connect & Muat" button ──
  const connectAndLoad = async () => {
    await connectWallet();
    if (contract) await explorerLoadAll();
  };
  // Exposed untuk inline onclick di HTML
  window.connectAndLoadExplorer = connectAndLoad;

  // ── Auto-reconnect: cek apakah sudah pernah konek ──
  if (window.ethereum) {
    window.ethereum.request({ method: 'eth_accounts' }).then(accounts => {
      if (accounts.length > 0) connectWallet();
    }).catch(() => {});
  }

  // ── Smooth scroll untuk anchor links ──
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      const target = document.querySelector(a.getAttribute('href'));
      if (target) {
        const y = target.getBoundingClientRect().top + window.scrollY - 80;
        window.scrollTo({ top: y, behavior: 'smooth' });
      }
    });
  });

});
